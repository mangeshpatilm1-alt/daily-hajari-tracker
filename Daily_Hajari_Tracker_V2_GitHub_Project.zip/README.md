# Daily Hajari Tracker V2

This repository contains the web app in `www/index.html` and the Capacitor configuration used to build an Android debug APK with GitHub Actions.

## Build
Push the files to the `main` branch, then open **Actions** and run **Build Daily Hajari APK** (or let the workflow run after a push). Download the `Daily-Hajari-Tracker-APK` artifact from the completed workflow run.
